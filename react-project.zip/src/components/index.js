import Proyect from './Proyect';

export default { Proyect };
