/**
 * This source code is exported from pxCode, you can get more document from https://www.pxcode.io
 */
import React from 'react';
import { StyleSheet, css } from 'aphrodite/no-important';

export default function Proyect(props) {
  return (
    <div className={`proyect ${css(styles.group, styles.group_layout)}`}>
      <div className={css(styles.flex, styles.flex_layout)}>
        <div className={css(styles.flex1, styles.flex1_layout)}>
          <h2
            className={css(
              styles.medium_title_box,
              styles.medium_title_box_layout
            )}>
            <pre className={css(styles.medium_title)}>{'Checo.sh '}</pre>
          </h2>
          <div className={css(styles.flex1_spacer)} />
          <h3 className={css(styles.home, styles.home_layout)}>{'Home'}</h3>
          <div className={css(styles.flex1_spacer1)} />
          <h3 className={css(styles.about, styles.about_layout)}>{'About'}</h3>
          <div className={css(styles.flex1_spacer2)} />
          <h3 className={css(styles.contact, styles.contact_layout)}>
            {'Contact'}
          </h3>
        </div>

        <hr className={css(styles.line, styles.line_layout)} />
        <h3 className={css(styles.subtitle_box, styles.subtitle_box_layout)}>
          <pre className={css(styles.subtitle)}>
            {'Hi, I’m Sergio Salazar '}
          </pre>
        </h3>

        <div
          className={css(
            styles.highlights_wrap,
            styles.highlights_wrap_layout
          )}>
          <h5
            className={css(
              styles.highlights_box,
              styles.highlights_box_layout
            )}>
            <pre className={css(styles.highlights)}>
              {
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non varius sed donec aenean elementum. Ut ut ornare a amet.consectetur adipiscing elit. Aenean volutpat at amet '
              }
            </pre>
          </h5>
          <h5
            className={css(
              styles.highlights1_box,
              styles.highlights1_box_layout
            )}>
            <pre className={css(styles.highlights)}>
              {
                'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non varius sed donec aenean elementum. Ut ut ornare a amet.consectetur adipiscing elit. Aenean volutpat at amet '
              }
            </pre>
          </h5>
        </div>

        <h3 className={css(styles.experience, styles.experience_layout)}>
          {'Experience'}
        </h3>
        <h4
          className={css(
            styles.highlights2_box,
            styles.highlights2_box_layout
          )}>
          <pre className={css(styles.highlights2)}>
            {'Software Engineer  @ Axtel (2017 - 2020)'}
          </pre>
        </h4>
        <h5
          className={css(
            styles.highlights3_box,
            styles.highlights3_box_layout
          )}>
          <pre className={css(styles.highlights)}>
            {
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat at amet tellus. Vulputate platea velit et odio id gravida. enean volutpat at amet '
            }
          </pre>
        </h5>
        <h4
          className={css(
            styles.highlights4_box,
            styles.highlights4_box_layout
          )}>
          <pre className={css(styles.highlights4)}>
            {'QA Analyst  @ Izzi (2015 - 2016)'}
          </pre>
        </h4>
        <h5
          className={css(
            styles.highlights5_box,
            styles.highlights5_box_layout
          )}>
          <pre className={css(styles.highlights)}>
            {
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat at amet tellus. Vulputate platea velit et odio id gravida. '
            }
          </pre>
        </h5>
        <h4
          className={css(
            styles.highlights6_box,
            styles.highlights6_box_layout
          )}>
          <pre className={css(styles.highlights6)}>
            {'QA Analyst  @ Izzi (2015 - 2016)'}
          </pre>
        </h4>
        <h5
          className={css(
            styles.highlights7_box,
            styles.highlights7_box_layout
          )}>
          <pre className={css(styles.highlights)}>
            {
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat at amet tellus. Vulputate platea velit et odio id gravida. '
            }
          </pre>
        </h5>
        <h3 className={css(styles.education, styles.education_layout)}>
          {'Education'}
        </h3>
        <h5
          className={css(
            styles.highlights8_box,
            styles.highlights8_box_layout
          )}>
          <pre className={css(styles.highlights8)}>
            {'Ingeniero en tecnologia de software, FIME, UNAL (2017 - 2022) '}
          </pre>
        </h5>
        <hr className={css(styles.line, styles.line_layout1)} />

        <div className={css(styles.flex2, styles.flex2_layout)}>
          <h3
            className={css(
              styles.sergio_salazar,
              styles.sergio_salazar_layout
            )}>
            {'Sergio Salazar'}
          </h3>
          <div className={css(styles.flex2_spacer)} />
          <div className={css(styles.flex2_col)}>
            <div
              style={{
                '--src': `url(${require('assets/605d9a79252c75782953c3156e94a88a.png')})`
              }}
              className={css(styles.group1, styles.group1_layout)}
            />
          </div>
          <div className={css(styles.flex2_spacer1)} />
          <div className={css(styles.flex2_col1)}>
            <div
              style={{
                '--src': `url(${require('assets/c887b67bd8bbcac72d72cb96d8031f02.png')})`
              }}
              className={css(styles.group2, styles.group2_layout)}
            />
          </div>
          <div className={css(styles.flex2_spacer2)} />
          <div
            style={{
              '--src': `url(${require('assets/89f416e1c656bc9722869598ee90e7fb.png')})`
            }}
            className={css(styles.image, styles.image_layout)}
          />
          <div className={css(styles.flex2_spacer3)} />
          <div className={css(styles.flex2_col2)}>
            <div
              style={{
                '--src': `url(${require('assets/49c11579d9b4f46dfd8c5855f8af1e5a.png')})`
              }}
              className={css(styles.group3, styles.group3_layout)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

Proyect.inStorybook = true;

const styles = StyleSheet.create({
  group: {
    display: 'flex',
    backgroundColor: 'rgb(255,255,255)'
  },
  group_layout: {
    position: 'relative',
    minHeight: 1058,
    flexGrow: 1,
    margin: 0
  },
  flex: {
    display: 'flex',
    flexDirection: 'column'
  },
  flex_layout: {
    position: 'relative',
    overflow: 'visible',
    flexGrow: 1,
    margin: '22px 0px'
  },
  flex1: {
    display: 'flex'
  },
  flex1_layout: {
    position: 'relative',
    overflow: 'visible',
    margin: '0px 164px'
  },
  medium_title: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '500 26px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  medium_title_box: {},
  medium_title_box_layout: {
    position: 'relative',
    margin: 0
  },
  flex1_spacer: {
    display: 'flex',
    flex: '0 1 590px'
  },
  home: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  home_layout: {
    position: 'relative',
    margin: '0px 0px 8px'
  },
  flex1_spacer1: {
    display: 'flex',
    flex: '0 1 6px'
  },
  about: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  about_layout: {
    position: 'relative',
    margin: '0px 0px 8px'
  },
  flex1_spacer2: {
    display: 'flex',
    flex: '0 1 6px'
  },
  contact: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  contact_layout: {
    position: 'relative',
    margin: '0px 0px 8px'
  },
  line: {
    backgroundColor: 'rgb(0,0,0)'
  },
  line_layout: {
    position: 'relative',
    height: 0.3,
    margin: '17.85px 0px 0px'
  },
  subtitle: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  subtitle_box: {},
  subtitle_box_layout: {
    position: 'relative',
    margin: '68.85px 164px 0px'
  },
  highlights_wrap: {
    display: 'flex'
  },
  highlights_wrap_layout: {
    position: 'relative',
    minHeight: 39,
    margin: '24px 183px 0px 164px'
  },
  highlights: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    margin: 0,
    font: '300 16px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  highlights_box: {},
  highlights_box_layout: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    flexGrow: 1,
    right: 0
  },
  highlights1_box: {},
  highlights1_box_layout: {
    position: 'relative',
    flexGrow: 1,
    margin: 0
  },
  experience: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  experience_layout: {
    position: 'relative',
    margin: '53px 164px 0px'
  },
  highlights2: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '500 18px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  highlights2_box: {},
  highlights2_box_layout: {
    position: 'relative',
    margin: '18px 164px 0px'
  },
  highlights3_box: {},
  highlights3_box_layout: {
    position: 'relative',
    margin: '17px 183px 0px 164px'
  },
  highlights4: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '500 18px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  highlights4_box: {},
  highlights4_box_layout: {
    position: 'relative',
    margin: '49px 164px 0px'
  },
  highlights5_box: {},
  highlights5_box_layout: {
    position: 'relative',
    margin: '18px 183px 0px 164px'
  },
  highlights6: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '500 18px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  highlights6_box: {},
  highlights6_box_layout: {
    position: 'relative',
    margin: '49px 164px 0px'
  },
  highlights7_box: {},
  highlights7_box_layout: {
    position: 'relative',
    margin: '21px 183px 0px 164px'
  },
  education: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  education_layout: {
    position: 'relative',
    margin: '36px 164px 0px'
  },
  highlights8: {
    overflow: 'visible',
    marginTop: 0,
    marginBottom: 0,
    font: '300 16px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px',
    whiteSpace: 'pre-wrap'
  },
  highlights8_box: {},
  highlights8_box_layout: {
    position: 'relative',
    margin: '24px 164px 0px'
  },
  line_layout1: {
    position: 'relative',
    height: 0.3,
    margin: '168.34px 0px 0px'
  },
  flex2: {
    display: 'flex'
  },
  flex2_layout: {
    position: 'relative',
    overflow: 'visible',
    margin: '67.36px 164px 6px'
  },
  sergio_salazar: {
    font: '500 20px/1.2 "Fira Code", Helvetica, Arial, serif',
    color: 'rgb(0,0,0)',
    letterSpacing: '0px'
  },
  sergio_salazar_layout: {
    position: 'relative',
    margin: '5px 0px 1px'
  },
  flex2_spacer: {
    display: 'flex',
    flex: '0 1 634.75px'
  },
  flex2_col: {
    display: 'flex',
    flex: '0 1 22.5px'
  },
  group1: {
    display: 'flex',
    background: 'var(--src) center center / cover no-repeat'
  },
  group1_layout: {
    position: 'relative',
    minHeight: 22.5,
    flexGrow: 1,
    margin: '2.75px 0px 4.75px'
  },
  flex2_spacer1: {
    display: 'flex',
    flex: '0 1 12.75px'
  },
  flex2_col1: {
    display: 'flex',
    flex: '0 1 30px'
  },
  group2: {
    display: 'flex',
    background: 'var(--src) center center / contain no-repeat'
  },
  group2_layout: {
    position: 'relative',
    minHeight: 30,
    flexGrow: 1,
    margin: 0
  },
  flex2_spacer2: {
    display: 'flex',
    flex: '0 1 11.5px'
  },
  image: {
    background: 'var(--src) center center / cover no-repeat'
  },
  image_layout: {
    position: 'relative',
    height: 23.03,
    width: 25,
    minWidth: 25,
    margin: '5.75px 0px 1.22px'
  },
  flex2_spacer3: {
    display: 'flex',
    flex: '0 1 16.5px'
  },
  flex2_col2: {
    display: 'flex',
    flex: '0 1 20px'
  },
  group3: {
    display: 'flex',
    background: 'var(--src) center center / contain no-repeat'
  },
  group3_layout: {
    position: 'relative',
    minHeight: 20,
    flexGrow: 1,
    margin: '5.96px 0px 4.04px'
  }
});
