import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import Proyect from 'components/Proyect';

import './App.css';
import './fonts.css';

class App extends Component {
  render() {
    return (
      <Router hashType="noslash" basename={process.env.BASE_PATH}>
        <Switch>
          <Route exact path="/">
            <div>
              pxCode Screen List: <br />
              <Link to="/Proyect">Proyect</Link>
            </div>
          </Route>

          <Route exact path="/Proyect" component={Proyect} />
        </Switch>
      </Router>
    );
  }
}

export default App;
